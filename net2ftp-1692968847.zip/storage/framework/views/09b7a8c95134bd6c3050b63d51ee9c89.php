<?php echo e($slot); ?>

<?php /**PATH /home/www/crmfitness.eu/www/crmfitness.eu/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>